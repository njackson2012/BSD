﻿using System.Collections;
using System.Collections.Generic;
using System;
using System.Net.Sockets;
using System.Net;
using UnityEngine;

public class TelemetryServer : MonoBehaviour {

    private Socket sock;
    IPAddress addr;
    IPEndPoint endPoint;
    Vector3 lastPosition;
    Vector3 velocity;
    Vector3 rotation;

    double pitch, roll, xPos, yPos, zPos, xVel, yVel, zVel;

	// Use this for initialization
	void Start () {
        sock = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        addr = IPAddress.Parse("127.0.0.1");
        endPoint = new IPEndPoint(addr, 4123);
        lastPosition = this.transform.position;
    }
	
	// Update is called once per frame
	void Update () {
        byte[] msg = new byte[32];
        if (Time.timeScale != 0 && Time.deltaTime != 0)
        {
            velocity = (transform.position - lastPosition) / Time.deltaTime;
        }
        lastPosition = transform.position;
        rotation = transform.rotation.eulerAngles;
        pitch = rotation.x > 180F ? rotation.x - 360F : rotation.x;
        roll = rotation.z > 180F ? rotation.z - 360F : rotation.z;
        xPos = transform.position.x;
        yPos = transform.position.y;
        zPos = transform.position.z;
        xVel = velocity.x;
        yVel = velocity.y;
        zVel = velocity.z;
        copyDouble(xPos, msg, 0);
        copyDouble(yPos, msg, 8);
        copyDouble(zPos, msg, 16);
        copyDouble(xVel, msg, 24);
        copyDouble(yVel, msg, 32);
        copyDouble(zVel, msg, 40);
        copyDouble(pitch, msg, 48);
        copyDouble(roll, msg, 56);
        sock.SendTo(msg, endPoint);
    }

    void copyDouble(double n, byte[] msg, int offset)
    {
        Array.Copy(BitConverter.GetBytes(n), 0, msg, offset, 8);
    }
}
