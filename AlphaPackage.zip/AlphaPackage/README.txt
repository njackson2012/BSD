Hey folks.

I made a super messy, but hopefully helpful guide for installing the SimTools plugin. It's gonna take a little bit of muscling about, but I believe in you! Don't hesitate to reach out if you get stuck.

As for the telemetry server, you need to attach it to the main game object. The two should communicate just fine....I hope. That's what testing is for!

Cheers,
Nick